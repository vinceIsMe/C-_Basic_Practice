# include<iostream>

using namespace std; 
struct Point{
    int x;
    int y;
};

int main(int argc, const char** argv) {
    Point a[3] ;
    cout << sizeof(Point)<<" "<<sizeof(a) <<" \n" ;
    cout << &a <<"\n" ;
    for(int i= 0 ; i <3 ; i++){
        cout <<&a[i] <<" "<<&a[i].x <<" " <<&a[i].y <<"\n" ;
    }
    Point *b = new Point[3];
    cout << sizeof(b) << endl;
    return 0;
}