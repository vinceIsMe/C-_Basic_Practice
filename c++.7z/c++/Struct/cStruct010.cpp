#include <iostream>

using namespace std ;
typedef double Dollar ;
int exchange(Dollar from ,double rate );

int main() {
    Dollar NT , US ;
    cin >> US ;
    NT = exchange(US ,29) ;
    cout << NT <<endl;
    return 0;
}
int exchange(Dollar from , double rate ){
    return from * rate ;
}