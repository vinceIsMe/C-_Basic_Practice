#include <iostream>
#include <cmath>
using namespace std;

struct Point{
    int x ; 
    int y ; 
    double dostOri();
};
double Point::dostOri()
{
    return sqrt(pow(x,2)+ pow(y,2));
}

int main(){
    Point a = {3 , 4};
    cout << a.dostOri();
    return 0;
}