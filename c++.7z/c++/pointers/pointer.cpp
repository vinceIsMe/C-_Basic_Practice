#include <iostream>
using namespace std;

int main() {
    // 動態分配一個包含 5 個整數的陣列
    int* arr = new int[5];

    for (int i = 0; i < 5; ++i) {
        arr[i] = i + 1;  // 將元素初始化為 1, 2, 3, 4, 5
    }

    // 印出指向陣列的指標
    cout << "Address of the array: " << arr << endl;

    // 印出指向陣列的第一個元素的指標 (即陣列的第一個整數)
    cout << "Value at the address: " << *arr << endl;

    cout << "Values of the array: ";
    for (int i = 0; i < 5; ++i) {
        cout << arr[i] << " \n";
    }
    cout << "Addresses of the array elements: ";
    for (int i = 0; i < 5; ++i) {
        cout << &arr[i] << " ";
    }
    cout << endl;
    // 釋放動態分配的記憶體
    cout << "Addresses of the array elements using *: \n";
    for (int i = 0; i < 5; ++i) {
        cout << arr << " ";  // 使用 * 取得指標所指向的值（即元素的值）
        arr++;  // 移動指標到下一個元素
    }
    cout << endl;

    delete[] arr;

    return 0;
}