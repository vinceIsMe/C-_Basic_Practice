# include <iostream>

using namespace std; 

int main(){
    int *ptr = 0 ;
    int  refInt = 10 ; 
    cout <<"the value of ptr " << ptr <<"\n";
    cout <<"the address of ptr " << &ptr <<"\n" ;
    cout <<"the size of ptr : " <<sizeof(ptr) << "\n";
    cout << "-------------------------------------\n" ;

    double *doublePtr = 0; 
    cout <<"the value of doublePtr " << doublePtr <<"\n";
    cout <<"the address of doublePtr " << &doublePtr <<"\n" ;
    cout  <<"the size of ptr : " << sizeof(doublePtr)<< "\n";


}