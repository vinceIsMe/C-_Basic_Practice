#include <iostream>
using namespace std; 

int main(){
    double a[3] = {10.5 , 11.5 , 13.5 };
    double *b = &a[0];
    double *c = &a[2];
    cout << *b <<" " << b << endl;
    cout << c -b <<endl;

    b++ ;
    cout << *b <<" " << b << endl;

}