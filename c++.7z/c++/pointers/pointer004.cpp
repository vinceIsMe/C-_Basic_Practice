#include <iostream>
using namespace std ; 

int main(){

    int r = 3 ; 
    int ** array = new int*[r];
    
    for (int i = 0 ; i<r ; i++){
        array[i] = new int[i+1] ;
        for(int j = 0 ; j <=i; j++){
            array[i][j] = j+1 ;
        }
    }
    cout <<"this is array " <<array <<endl;
    cout <<"this is array " <<&array <<endl;
    cout << "this is array[0] " <<array[0] <<endl;
    cout << "this is array[0][0] " << &array[0][0] <<endl;
    cout << "this is array[0][1] " << &array[0][1] <<endl;
    cout << "this is array[0][2] " << &array[0][2] <<endl;
    cout << "this is array[1] " <<array[1] <<endl;
    cout << "this is array[1][0] " << &array[1][0] <<endl;
    cout << "this is array[1][1] " << &array[1][1] <<endl;
    cout << "this is array[1][2] " << &array[1][2] <<endl;
    cout << "this is array[2] " <<array[2] <<endl;
    cout << "this is array[2][0] " << &array[2][0] <<endl;
    cout << "this is array[2][1] " << &array[2][1] <<endl;
    cout << "this is array[2][2] " << &array[2][2] <<endl;
    cout <<endl;

    int ** array1 = new int*[r];
    
    for (int i = 0 ; i<r ; i++){
        array1[i] = new int[3] ;
        for(int j = 0 ; j <=i; j++){
            array1[i][j] = j+1 ;
        }
    }
     for( int i = 0 ; i < r ; i++){
        for(int j = 0 ; j < r ; j++){
            cout << array1[i][j] <<" ";

        }
        cout << endl;
    }
    cout <<"this is array1 " <<array1 <<endl;
    cout <<"this is array1 " <<&array1 <<endl;
    cout << "this is array1[0] " <<array1[0] <<endl;
    cout << "this is array1[0][0] " << &array1[0][0] <<endl;
    cout << "this is array1[0][1] " << &array1[0][1] <<endl;
    cout << "this is array1[0][2] " << &array1[0][2] <<endl;
    cout << "this is array1[1] " <<array1[1] <<endl;
    cout << "this is array1[1][0] " << &array1[1][0] <<endl;
    cout << "this is array1[1][1] " << &array1[1][1] <<endl;
    cout << "this is array1[1][2] " << &array1[1][2] <<endl;
    cout << "this is array1[2] " <<array1[2] <<endl;
    cout << "this is array1[2][0] " << &array1[2][0] <<endl;
    cout << "this is array1[2][1] " << &array1[2][1] <<endl;
    cout << "this is array1[2][2] " << &array1[2][2] <<endl;

    int array2[3][3] ;

    for (int i = 0 ;i <r ; i++){
        for(int j = 0 ; j < r ; j++){
            array2[i][j] = j+1 ;
        }
    }
    for( int i = 0 ; i < r ; i++){
        for(int j = 0 ; j < r ; j++){
            cout << array2[i][j] <<" ";

        }
        cout << endl;
    }
    cout <<"this is array2 " <<array2 <<endl;
    cout <<"this is array2 " <<&array2 <<endl;
    cout << "this is array2[0] " <<array2[0] <<endl;
    cout << "this is array2[0][0] " << &array2[0][0] <<endl;
    cout << "this is array2[0][1] " << &array2[0][1] <<endl;
    cout << "this is array2[0][2] " << &array2[0][2] <<endl;
    cout << "this is array2[1] " <<array2[1] <<endl;
    cout << "this is array2[1][0] " << &array2[1][0] <<endl;
    cout << "this is array2[1][1] " << &array2[1][1] <<endl;
    cout << "this is array2[1][2] " << &array2[1][2] <<endl;
    cout << "this is array2[2] " <<array2[2] <<endl;
    cout << "this is array2[2][0] " << &array2[2][0] <<endl;
    cout << "this is array2[2][1] " << &array2[2][1] <<endl;
    cout << "this is array2[2][2] " << &array2[2][2] <<endl;
    

}