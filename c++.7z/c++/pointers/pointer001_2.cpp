# include<iostream>
using namespace std ;

int main() {
    cout << " ----------------------INTEGER -------------------------------"<< endl;
    int a = 5 ;
    int *aPtr = &a ;
    cout << "&a: " << &a << endl;
    cout <<" aPtr: "<< aPtr << endl;
    cout << "*aPtr:  " << *aPtr << endl;
    cout << "&aPtr: " << &aPtr << endl; // aPtr 自己的位子

    cout << "--------------------------------------------------------------" <<endl ;
    cout << "----------------------Double----------------------------------" <<endl ;
    double b = 10.5 ;
    double *bptr = &b ;
    cout << "&b: " << &b << endl;
    cout <<" bptr: "<< bptr << endl;
    cout << "*bptr:  " << *bptr << endl;
    cout << "&bptr: " << &bptr << endl;// bPtr 自己的位子

    cout << "--------------------------------------------------------------" <<endl ;



}