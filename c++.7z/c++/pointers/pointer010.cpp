#include<iostream>
using namespace std; 

int main(){
    char s[100] = "12345";
    char *p = &s[0];
    char *q = s;
    cout << *p <<endl; 
    cout << p <<endl;
    cout << &s[0] <<endl;
    cout << q <<endl; // 這裡會print 出 12345 背起來就好了
    cout << "Address of s: " << static_cast<void*>(q) << endl;
    int a[5] = {1, 2, 3, 4, 5};
    int *p2 = &a[0];  // 或者 int *p = &a[0];
    cout << *p2 <<endl; 
    cout << p2 << endl;

    
}