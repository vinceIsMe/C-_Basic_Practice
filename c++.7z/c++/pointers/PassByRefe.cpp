#include <iostream>
using namespace std;
// int i = 5 ;
void swap(int &x , int &y ); 
int main(){
    int a = 10 , b = 20 ;
    cout << a <<" " << b << endl;
    swap(a ,b) ; 
    cout << a << " " << b << endl;
}
void swap(int &x ,int &y ){
    int temp = x ; 
    x = y ;
    y = temp ;  
}
//這篇告訴我們Int x int y 並不能改變裡面的職
// pass by value 算是在記憶體上new 兩個新的值做完才消散
// 所以要要reference或其他方式