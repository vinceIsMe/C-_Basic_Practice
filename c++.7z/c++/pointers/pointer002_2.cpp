#include <iostream>

using namespace std;

void swap(int *x ,int *y); 
void swap(int &x ,int &y);
int main(){
    int a = 10 , b = 20 ;
    cout << a <<" " << b <<"\n";
    int *ptrA = &a ;
    int *ptrB = &b ;
    swap(*ptrA , *ptrB);
    cout << a <<" " <<b << endl;
    swap(&a ,&b);
    cout << a <<" "<<b<< endl;


}
void swap(int *ptrA ,int *ptrB)
{
    int temp = *ptrA ;
    *ptrA = *ptrB ;
    *ptrB = temp;
}
void swap(int &x ,int &y)
{
    cout <<"this is the &x and &y " <<&x <<" "<<&y <<endl;
    cout <<"this is the x and y " <<x <<" "<<y <<endl;
    int temp = x ; 
    x = y ; 
    y = temp ;
}
