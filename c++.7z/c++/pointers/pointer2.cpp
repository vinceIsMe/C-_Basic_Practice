# include <iostream>
using namespace std ;
void print(int ** ,int) ;
void print1D( int * , int);

int main() { 

    int r = 3  ; 
    int **array = new int *[r];

    for (int i = 0 ; i <r ; i++ ){
        
        array[i] = new int[ i + 1 ] ; // 創建一個給array[0]

        for (int j = 0 ; j <= i ; j++){
            array[i][j] = j + 1 ;
        }
    }
    cout << array << "\n";
    cout << *array;
    print( array ,r) ;
    delete []array;

}
void print(int ** array , int r){
    for (int i = 0  ; i < r ; i ++){
        print1D(array[i] , i+1);
    }
}
void print1D(int *arr , int n){
    for(int i = 0 ; i < n ; i++ ){
        cout << arr[i] << " ";
    }
    cout << endl;
}
