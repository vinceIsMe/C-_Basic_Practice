#include <iostream>
using namespace std ;

int main() {
    int array[5] = {1,2,3,0,0};
    int size = 5 ;
    
    cout << "This is the address of array: ";
    cout << array <<"\n";
    for(int i = 0 ; i < size ; i++ ){
        cout << array[i] <<endl;
    }

}