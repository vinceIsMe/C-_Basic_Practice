#include <iostream>

using namespace std; 

int main(){
    int a = 10 ;
    int *p1  = &a ; 
    int *p2  = nullptr ;
    cout << "value of a = " << a << " \n" ;
    cout << "address of a = " << &a <<"\n" ; 
    cout << "value of p1 = " << p1 <<"\n" ; 
    cout << "address of p1 = " << &p1 << "\n" ;
    cout << "value of the variable pointed by p1 = " <<*p1 <<"\n";

    cout <<"value of p2 = " << p2 <<endl; 
    cout <<"address of p2 = " << &p2 <<endl; 
    // cout <<" the variable point by p2 =  " << *p2 <<"\n" ;//我的P2指向空的就沒有住址了

    int c = 10 ; 
    int &d = c ;
    cout << "this is the c& d \n" ;
    cout << &c <<endl ;
    cout << &d <<endl;
    cout << d <<endl;

}