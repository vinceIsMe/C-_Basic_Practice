#include<iostream>
using namespace std;

int *ShowAll(int a[] ,int n){
    for(int i = 0 ;i < n ; i++){
        if(a[i]<0){
            return &a[i];
        }
    }
}

int main(){
    int a[5] = {0};

    for(int i = 0 ; i <5 ; i++){
        cin >> a[i];
    }
    int  *p =ShowAll(a , 5);
    
    cout << *p <<" " <<p <<endl;

}