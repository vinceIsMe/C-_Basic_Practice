#include<iostream>
using namespace std ;

int main(){

    char *p  ;
    p = "hi";
    cout <<*p <<endl;
    cout << p <<endl;
}