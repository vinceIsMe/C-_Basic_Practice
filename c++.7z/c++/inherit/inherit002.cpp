#include <iostream>
using namespace std;
class MyVector
{
protected: 
    int n;
    int j;
    double *m;

public:
    MyVector(); //  defaut constructor
    MyVector(int dim, double v[]);
    MyVector(const MyVector &v) ;
    ~MyVector();
    bool operator==
    (const MyVector &v ) const;
    void print() const;
    void print();
    double operator[](int i) const ;
    double& operator[](int i) ;
    const MyVector operator+ (const MyVector &v);
    const MyVector& operator+=(const MyVector &v);
    const MyVector operator+(double d ) ;
    MyVector& operator =(const MyVector &v);
    friend const MyVector operator+(const MyVector &v, double d);
};
const MyVector MyVector::operator+(double d){
    MyVector sum(*this) ;
    for(int i = 0 ; i < n ;i++){
        sum[i] +=d ;
    }
    return sum;
}
const MyVector MyVector::operator+(const MyVector &v){
    MyVector sum(*this);
    sum += v;
    return sum ; 
}
const MyVector& MyVector :: operator+=(const MyVector &v){
    if( this ->n == v.n ){
        for(int i = 0 ; i< n ; i++){
            this ->m[i] += v.m[i];
        }
        return *this ;
    }
    if( this-> n != v.n){
        cout << "the length wrong"<<endl;
    }
}
MyVector& MyVector::operator=(const MyVector &v){
    if (this != &v){
    if( this->n != v.n){
        delete []this->m ;
        this->n = v.n;
        this->m = new double[this->n];
    }
    for(int i = 0 ; i < n ; i++){
        this->m[i] = v.m[i] ;
    }
    
    return *this ;
    }

}
double &MyVector::operator[](int i ){
     if( i < 0 || i >= n)
        exit(1);
    return m[i] ;
}
double MyVector::operator[](int i) const{
    if( i < 0 || i >= n)
        exit(1);
    return m[i] ;
}
bool MyVector ::operator==(const MyVector &v)const{
    if(n != v.n){
        return false ;
    }
  
    
        for(int i = 0 ; i < n ; i++){
            if(m[i] != v.m[i]){
                return false ;
            }
        }
    
    return true ;
}
MyVector :: ~MyVector()
{
    delete []m;
}
void MyVector::print()
{
    for (int i = 0; i < n; i++)
    {
        cout << m[i] << " ";
    }
    cout << endl;
    for (int i = 0; i < n; i++)
    {
        cout << &m[i] << " ";
    }
    cout << endl;
}
void MyVector::print() const
{
    cout << "const" <<endl;
    for (int i = 0; i < n; i++)
    {
        cout << m[i] << " ";
    }
    cout << endl;
    for (int i = 0; i < n; i++)
    {
        cout << &m[i] << " ";
    }
    cout << endl;
}

MyVector::MyVector()  
{
    n = 0;
    m = nullptr;
}

MyVector ::MyVector(const MyVector &v ){
    this->n = v.n ;
    this->m = v.m ;
}
MyVector::MyVector(int n, double v[])
{
    this->n = n;
    this->m = new double[n];
    for (int i = 0; i <this->n; i++)
    {
        this->m[i] = v[i];
    }
}
const MyVector operator+ (const MyVector &v ,double d){
    MyVector sum(v) ; 
    for(int i = 0 ; i < v.n ;i++){
        sum[i] +=d ;
    }
    return sum ;
}
const MyVector operator+(double d ,const MyVector &v)
{
    return v+d; 
}
class MyVector2D : public MyVector
{
    public:
    MyVector2D();
    MyVector2D(double m[]);
    void print() const;
    void setValue(double i1 ,double i2);

};
void MyVector2D ::print() const
{
    MyVector::print();
}
MyVector2D ::MyVector2D() 
{
    this->n = 2 ; 
}
MyVector2D :: MyVector2D(double m[]) :MyVector(2,m)
{
    
}
void MyVector2D::setValue(double i1 ,double i2){
    if(this -> m == nullptr){
        this -> m = new double[2] ; 
    }
    this->m[0] = i1 ;
    this->m[0] = i2 ;
}
class NNvector2D : public MyVector2D
{
    public :
        NNvector2D() ;
        NNvector2D(double m[]);
        void setValue(double i1 ,double i2) ;
};
NNvector2D ::NNvector2D()
{
    //繼承上一個
}
NNvector2D ::NNvector2D(double m[])
{
    this ->m = new double[2] ;
    this -> m[0] = m[0] >=0 ? m[0] : 0 ;
    this -> m[1] = m[1] >= 0 ? m[1] : 0 ;
}
void NNvector2D ::setValue(double i1 ,double i2)
{
    if(this -> m == nullptr){
        this ->m = new double[2] ;
    }
    this -> m[0] = m[0] >=0 ? m[0] : 0 ;
    this -> m[1] = m[1] >= 0 ? m[1] : 0 ;
}
int main()
{
    double i[2] = {1,2};
    MyVector2D v(i) ;
    v.print();
}