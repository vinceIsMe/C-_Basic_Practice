#include <iostream>
using namespace std ;

class A
{
    protected :
        int i ;
    public :
        void a() { cout << "a \n" ;} 
        void f() { cout << "af \n" ;}
};
class B :public A
{
    private :
        int j ;
    public :
        void b(){cout << "b \n" ;}
        void f(){cout << "bp \n" ;}
};
class Parent
{
    protected :
        int x ; 
        int y ; 
    public : 
        Parent(int a ,int b) :x(a) ,y(b){}
        virtual void print() {cout << x << " " << y ;}
};
class Child : public Parent 
{
    protected :
        int z ;  
    public :
        Child(int a ,int b ,int c ) :Parent(a,b)
        {
            z = c ;
        }
        void print() {
            cout << z;}
};
class Child2 : public Parent 
{
    protected :
        int z ;  
    public :
        Child2(int a ,int b ,int c ) :Parent(a,b)
        {
            z = c ;
        }
        void print() {
            Parent::print();
            cout << z;}
};
int main() {
    Child c(3,4,5) ;
    Child2 c2(3,4,5) ;
    Parent p = c ; // 5 is discarded 
    p.print() ;
    cout <<endl;
    Parent *D = &c ;
    D ->print() ;
    cout << endl;
    Parent *D2 = &c2 ;
    D2 ->print() ;
    cout << endl;
    
}