// #include <iostream>
// #include <cstring>
// #include <cmath>
// using namespace std; 
// class Character
// {
//     protected :
//         static const int Exp_LV = 100 ;
//         string name;
//         int level ;
//         int exp ; 
//         int power ; 
//         int knowledge ;
//         int luck ;
//         void levelUp (int pInc ,int kInc ,int linc) ;
//     public :
//         Character(string n , int lv ,int po ,int kn ,int lu);
//         void print();
//         void beatMonster(int exp);
//         string getName();
// };
// Character ::Character(string n ,int lv ,int po ,int kn ,int lu)
//                 :name(n) , level(lv) ,exp(pow(lv-1 ,2) * Exp_LV),power(po),knowledge(kn) ,luck(lu)
//                 {

//                 }
// void Character ::print(){
//     cout << this-> name <<": level" <<this->level <<"(EXP)" <<this ->power << "-" <<this ->knowledge <<"-"<<this ->luck <<endl;
// }
// string Character ::getName(){
//     return this -> name;
// }
// void Character ::beatMonster(int exp )
// {
//     this -> exp += exp ;
//     while(this ->exp >= pow(this-> level ,2) *Exp_LV){
//         this ->levelUp(0,0,0);
//     }

// }
// void Character ::levelUp(int pInc , int kInc ,int lInc) {
//     this -> level ++ ;
//     this -> power += pInc ;
//     this -> knowledge += kInc ;
//     this -> luck += lInc ;
// }
// class Warrior : public Character
// {
//     private:
//         static const int PO_LV = 10 ;
//         static const int KN_LV = 5 ;
//         static const int LU_LV = 5 ;
//     public :
//         Warrior(string n , int lv = 1 )
//         :Character(n , lv ,lv * PO_LV , lv * KN_LV , lv * LU_LV)
//         {}
//         void print(){ cout << "Warrior" ; Character :: print() ;}
//         void beatMonster(int exp )
//         {
//             this ->exp += exp ;
//             while(this-> exp >= pow(this->level ,2 ) * Exp_LV){
//                 this ->levelUp(PO_LV ,KN_LV , LU_LV) ;
//             }
//         }

// };
// class Wizard : public Character
// {
//     private:
//         static const int PO_LV = 4 ; //這邊主要要有static的原因是因為 static 是靜態變數 所以他們分享一個靜態變數就不用每個人都有獨立的這三個變數了
//         // 這樣可以節省資源
//         static const int KN_LV = 9 ;
//         static const int LU_LV = 7 ;
//     public :
//         Wizard(string n , int lv = 1 )
//         :Character(n , lv ,lv * PO_LV , lv * KN_LV , lv * LU_LV)
//         {}
//         void print(){ cout << "Wizard" ; Character :: print() ;}
//         void beatMonster(int exp )
//         {
//             this ->exp += exp ;
//             while(this-> exp >= pow(this->level ,2 ) * Exp_LV){
//                 this ->levelUp(PO_LV ,KN_LV , LU_LV) ;
//             }
//         }

// };
// int main() {
//     Character c1[3] ;
//     c1[0] =  Warrior("Alice" ,10) ;
//     c1[1] =  Wizard("sop" , 8) ;
//     c1[2] =  Warrior ("AMY" ,12) ;
//     for(int i = 0 ; i <3 ;i++){
//         c1[i].print() ;
//     }
//     // for(int i = 0 ; i <3 ;i++) {
//     //     delete c1[i] ;
//     // }
//     return 0;

// }   不會過