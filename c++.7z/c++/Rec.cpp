#include <iostream>
using namespace std;

double max(double [] , int len);

int main(){
    double a[5] = {5,4,6,3,7};

    cout << max(a , 5);
    return 0 ;
}


double max(double array[] , int len){
    if(len == 1){
        cout << "THe final one : " << array[0] <<endl;
        return array[0];
    }
    else{
        double subMax = max(array , len-1) ;
        if (array[len -1] >subMax){
            cout << "THe"<<len<<"one : " << array[len ] <<endl;
            return array[len -1] ;
            
        }
        else{
            cout << "THe"<<len<<"one: " << array[len ]<<endl;
            return subMax;
        }
    }
}