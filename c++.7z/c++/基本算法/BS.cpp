#include <iostream>
using namespace std ;
int BS(int *  , const int x , const int n );
int main() {
    int a[5] = {1 , 2 ,3 , 4 , 5 };
    int x = 3 ;
    int n = 5 ;
    BS(a ,x, n ) ;
    cout << BS ;
}

int BS(int *A , const int x , const int n){
    int left = 0 ; 
    int right = n - 1 ;
    while(left <= right){
        int middle = (left+right)/2 ; 
        if(x <A[middle]) right = middle-1;
        else if (x > A[middle]) left = middle + 1 ;
        else return middle ;
    }
    return -1 ;
}