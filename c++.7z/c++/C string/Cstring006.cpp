#include <iostream>
using namespace std ;

int main(){
    char *p = new char[100];
    p = "i am vincent !";
    cout << p <<"\n" ;
    cout << static_cast<void*>(p) << endl;
    // cout << &p[1] << endl;
    p ="123";
    cout << p << endl ;
    cout << &p <<endl ;
    //用pointer 的方式可以第一次指奏readonly 但之後就不能再跟動
    // 如果再用stirng 的方式去access就會不一樣
    
}