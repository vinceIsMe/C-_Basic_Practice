#include <iostream>

using namespace std; 

const int Len = 10 ;
int main(){
    char s[Len] = {0};
    int n = 0 ;

    do
    {
        cin >> s[n] ;
        n++ ;
    }while(s[n-1] != '#' && n <Len);
    for(int i= 0 ; i < n-1 ; i++){
        cout << s[i];
    }

    return 0;

}