#include <iostream>

using namespace std ;

int main() {
    // char s[100] = "12345";
    // char *p = s ;
    // cout << p <<endl;
    // cout <<p+2 <<endl;
    // cout << *p <<endl;
    // // return 0;
    // char a[100] = "12345";
    // // a = "123"; //compilation error
    // char *p = a ;
    // p = "abc";
    // // cin >>a ;
    // cout << p << endl;
    // cout << &p << endl ;
    // cout << a << endl ;
    // cout << &a <<endl;
    // //不同地方 為了區別不同


}