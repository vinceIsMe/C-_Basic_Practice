#include <iostream>
using namespace std ;

int main(){
    char name[4][100] = {"yaun" ,"min" ,"wen" ,"xiao"};

    cout << &name << "\n" ;
    cout << name <<"\n" ;
    cout << &name[1] <<endl;
    cout << name[1] <<endl;
}