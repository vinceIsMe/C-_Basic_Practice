#include <iostream>

using namespace std ;

int main(){
    int val[5] = {0};
    cout << val <<endl; //an adress 

    // char str[10] ;
    // cin >> str ;
    // cout << str;

    // char a[10] = "abcde FGH" ;
    // cout<< a <<"\n" ;
    // char b[10] = "abcd\0FGH" ;
    // cout << b << "\n";

    char a[10] = {0} ;
    // cin >> a ;
    // cout << a ;
    cin.getline(a , 19);
    cout << a <<endl;
    return 0 ;
}