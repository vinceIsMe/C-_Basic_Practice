#include <iostream>
#include <climits>
using namespace std; 

int main(){
    cout << INT_MIN << " " << INT_MAX << endl;
    double  a = 5.9;
    cout <<static_cast<int> (a) ;


}