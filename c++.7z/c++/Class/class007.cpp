#include <iostream>
using namespace std;
class MyVector
{
private: 
    int n;
    int j;
    int *m;

public:
    MyVector(); //  defaut constructor
    MyVector(int dim, int value =0);
    MyVector(const MyVector &v) ;
    ~MyVector();
    void print();
};
MyVector :: ~MyVector()
{
    delete []m;
}
void MyVector::print()
{
    for (int i = 0; i < n; i++)
    {
        cout << m[i] << " ";
    }
    cout << endl;
    for (int i = 0; i < n; i++)
    {
        cout << &m[i] << " ";
    }
    cout << endl;
}

MyVector::MyVector()  
{
    n = 0;
    m = nullptr;
}

MyVector ::MyVector(const MyVector &v ){
    n = v.n ;
    m = v.m ;
}
MyVector::MyVector(int dim, int value)
{
    n = dim;
    m = new int[n];
    for (int i = 0; i < n; i++)
    {
        m[i] = value;
    }
}
int main()
{
    // MyVector v1(5);
    // MyVector *ptrv = &v1;
    // v1.print();
    // ptrv->print();
    // cout << sizeof(&v1)<<endl;
    // cout <<sizeof(v1)<<endl;
    MyVector v1 (5,10 );
    MyVector v2 ;
    MyVector v3(v1);
    v1.print();
    v3.print();
    // shallow
    return 0;
}