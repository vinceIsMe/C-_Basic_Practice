#include <iostream>

using namespace std ;
class A{
    private :
        int a ;
    public :
        void f(){ cout << this <<"\n" ;
                //   cout << (*this).a << endl;                    
                   }
        A *g(){ return this ;}
};
int main(){
    A obj ;
    cout << &obj <<endl ;
    obj.f() ; 
    cout << (&obj == obj.g()) <<endl; //truth
    return 0;
}