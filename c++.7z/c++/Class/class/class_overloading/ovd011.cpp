#include <iostream>
using namespace std;
class MyVector
{
private: 
    int n;
    int j;
    double *m;

public:
    MyVector(); //  defaut constructor
    MyVector(int dim, double v[]);
    MyVector(const MyVector &v) ;
    ~MyVector();
    bool operator==
    (const MyVector &v ) const;
    void print();
    double operator[](int i) const ;
    double& operator[](int i) ;
};
double &MyVector::operator[](int i ){
     if( i < 0 || i >= n)
        exit(1);
    return m[i] ;
}
double MyVector::operator[](int i) const{
    if( i < 0 || i >= n)
        exit(1);
    return m[i] ;
}
bool MyVector ::operator==(const MyVector &v)const{
    if(n != v.n){
        return false ;
    }
  
    
        for(int i = 0 ; i < n ; i++){
            if(m[i] != v.m[i]){
                return false ;
            }
        }
    
    return true ;
}
MyVector :: ~MyVector()
{
    delete []m;
}
void MyVector::print()
{
    for (int i = 0; i < n; i++)
    {
        cout << m[i] << " ";
    }
    cout << endl;
    for (int i = 0; i < n; i++)
    {
        cout << &m[i] << " ";
    }
    cout << endl;
}

MyVector::MyVector()  
{
    n = 0;
    m = nullptr;
}

MyVector ::MyVector(const MyVector &v ){
    this->n = v.n ;
    this->m = v.m ;
}
MyVector::MyVector(int n, double v[])
{
    this->n = n;
    this->m = new double[n];
    for (int i = 0; i <this->n; i++)
    {
        this->m[i] = v[i];
    }
}
int main()
{
    double d1[5] = {1,2,3,4,5};
    MyVector a1(5 , d1 );

    double d2[4] = {1,2,3,4};
    MyVector a2(4,d2) ;
    const MyVector a3(a1);

    a2[0] = 999;
    if(a1 == a3 ){
        cout << a2[0] <<" " <<a3[0];
    }
    return 0;
}