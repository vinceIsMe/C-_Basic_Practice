#include <iostream>
using namespace std;
class MyVector
{
private: 
    int n;
    int j;
    int *m;

public:
    MyVector(); //  defaut constructor
    MyVector(int dim, int value =0);
    MyVector(int dim , int []);
    void print() ;
    int getN() ;
    int getM(int ) ;
};
int MyVector:: getN(){
    return n;
}
int MyVector :: getM(int i){
    return m[i];
}
MyVector ::MyVector(int d ,int v[]){
    n = d ; 
    m = new int[n];
    for(int i = 0 ; i < n ; i++){
        m[i] = v[i];
    }
}
void MyVector::print()
{
    for (int i = 0; i < n; i++)
    {
        cout << m[i] << " ";
    }
    cout << endl;
}

MyVector::MyVector()  
{
    n = 0;
    m = nullptr;
}


MyVector::MyVector(int dim, int value)
{
    n = dim;
    m = new int[n];
    for (int i = 0; i < n; i++)
    {
        m[i] = value;
    }
}
MyVector sum(MyVector *v1 ,MyVector *v2 , MyVector *v3){
    int n = v1->getN();
    int * sov = new int[n] ; 
    for(int i = 0 ; i < n ; i++){
        sov[i] = v1->getM(i) + v2->getM(i)+ v3->getM(i) ;
    }
    MyVector SumofVec(n,sov) ;
    return SumofVec;
}
int main(){
    // Create three vectors
    int values1[] = {1, 2, 3};
    int values2[] = {4, 5, 6};
    int values3[] = {7, 8, 9};

    MyVector v1(3, values1);
    MyVector v2(3, values2);
    MyVector v3(3, values3);

    // Print the original vectors
    cout << "Vector 1: ";
    v1.print();
    cout << "Vector 2: ";
    v2.print();
    cout << "Vector 3: ";
    v3.print();
    // MyVector *Pv1 = &v1 ;
    // MyVector *Pv2 = &v2 ;
    // MyVector *Pv3 = &v3 ;

    // Calculate the sum of vectors
    MyVector result = sum(&v1,  &v2, &v3);

    // Print the result vector
    cout << "Sum of Vectors: ";
    result.print();

    return 0;

}