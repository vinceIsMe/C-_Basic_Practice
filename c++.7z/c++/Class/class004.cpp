#include <iostream>
using namespace std;
class MyVector
{
private: 
    int n;
    int j;
    int *m;

public:
    MyVector(); //  defaut constructor
    MyVector(int dim, int value =0);
    void print();
};
void MyVector::print()
{
    for (int i = 0; i < n; i++)
    {
        cout << m[i] << " ";
    }
    cout << endl;
}

MyVector::MyVector()  
{
    n = 0;
    m = nullptr;
}


MyVector::MyVector(int dim, int value)
{
    n = dim;
    m = new int[n];
    for (int i = 0; i < n; i++)
    {
        m[i] = value;
    }
}
int main()
{   //------------------靜態 ------------------
    // MyVector v[3];
    // v[0].print();//run time erroe
    //--------------------------------------

    // MyVector *ptrV = new MyVector(5,5) ;
    // ptrV ->print() ;
    // delete ptrV ;
    // ----------------rub time error -------------------
    MyVector *ptrV2 = new MyVector[5] ;
    ptrV2->print() ;
    delete ptrV2;
    // ----------------rub time error -------------------
    // MyVector *ptrV = new MyVector(3,7);
    // ptrV -> print();

    MyVector *ptrArray[5] ; 
    for (int i = 0 ; i <5 ; i++){
        ptrArray[i] = new MyVector(i+1 ,i+1);
    }
    cout <<ptrArray[0];
    for (int i = 0 ; i <5 ; i++){
        cout << ptrArray[i] <<endl;
    }
    ptrArray[4]->print();
    //some delete statement
   
}