# include <iostream>
using namespace std ;

class Window
{
private:
    int width;
    int height;
    int locationX;
    int locationY;
    int status;
    static int barColor;
    
public:
    static int getBarColor();
    static void setBarColor(int color);
};
int Window::barColor = 0; // static variable需一開始用全域initializae
int Window::getBarColor()
{
    return barColor;
}
void Window::setBarColor(int color)
{
    barColor = color;
}

int main(){

}