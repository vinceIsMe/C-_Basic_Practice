#include<iostream>
using namespace std; 
class A
{
private:
    static int count;

public:
    A() { A::count++; }
    ~A() { A::count--; }
    static int getCount() { return A::count; }
};

int A::count = 0;

int main()
{
    if (true)
    {
        A a1, a2, a3;
    }

    cout << A::getCount() << endl;
    return 0;
}