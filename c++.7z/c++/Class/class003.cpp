#include <iostream>
using namespace std;
class MyVector
{
private: 
    int n;
    int j;
    int *m;

public:
    MyVector(); //  defaut constructor
    MyVector(int dim, int value =0);
    void print();
};
void MyVector::print()
{
    for (int i = 0; i < n; i++)
    {
        cout << m[i] << " ";
    }
    cout << endl;
}

MyVector::MyVector()  
{
    n = 0;
    m = nullptr;
}


MyVector::MyVector(int dim, int value)
{
    n = dim;
    m = new int[n];
    for (int i = 0; i < n; i++)
    {
        m[i] = value;
    }
}
int main()
{
    MyVector v1(5);
    MyVector *ptrv = &v1;
    v1.print();
    ptrv->print();
    cout << sizeof(&v1)<<endl;
    cout <<sizeof(v1)<<endl;

    return 0;
}